/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csv;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author Sylwia
 */
public class CSV {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        ArrayList<Submission> submissions = CsvFileReader.readCsvFile("task.csv");
        for (Submission sub : submissions) {
            sub.setRate(ThreadLocalRandom.current().nextInt(0, 5 + 1));
        }
        CsvFileWriter.writeCsvFile("submission.csv", submissions);
    }

}
