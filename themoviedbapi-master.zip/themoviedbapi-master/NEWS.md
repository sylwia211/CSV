See
[releases](https://github.com/holgerbrandl/themoviedbapi/releases)
for downloads and details

v1.3
---
- Implemented automatic rate-limit handling

v1.2
---
- Implemented rating support for TV Shows
- Implemented multi-search (contributed by ArcherZP)
- More complete unit-test coverage

v1.1
---
- improved tv series support
- added timezones
- added gravatar support

v1.0
---
- Initial release

