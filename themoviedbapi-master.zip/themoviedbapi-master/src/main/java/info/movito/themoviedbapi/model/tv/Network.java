package info.movito.themoviedbapi.model.tv;

import info.movito.themoviedbapi.model.core.NamedIdElement;


public class Network extends NamedIdElement {

}
