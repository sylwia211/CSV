package info.movito.themoviedbapi;

import info.movito.themoviedbapi.model.core.ResultsPage;
import info.movito.themoviedbapi.model.tv.TvEpisode;


public class TvEpisodesResultsPage extends ResultsPage<TvEpisode> {

}
