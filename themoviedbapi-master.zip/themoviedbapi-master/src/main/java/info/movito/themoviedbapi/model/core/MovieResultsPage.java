package info.movito.themoviedbapi.model.core;

import info.movito.themoviedbapi.model.MovieDb;


public class MovieResultsPage extends ResultsPage<MovieDb> {

}
