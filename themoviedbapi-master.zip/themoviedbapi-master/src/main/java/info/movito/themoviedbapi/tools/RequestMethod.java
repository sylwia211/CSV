package info.movito.themoviedbapi.tools;

public enum RequestMethod {

    GET, DELETE
}
