package info.movito.themoviedbapi;

import info.movito.themoviedbapi.model.core.ResultsPage;
import info.movito.themoviedbapi.model.tv.TvSeries;


public class TvResultsPage extends ResultsPage<TvSeries> {

}
